#!/usr/bin/env python3
"""Build outputs from the split sources.

dist/site/          deploy folder: root-absolute asset paths so nested clean URLs (/table/t2, /gift/LootBag-7631)
                    load images; plus _redirects, _headers, robots.txt and server/ + tools/
dist/preview.html   single-file preview with relative paths (double-click to open locally; hash routing)
dist/artifact.html  page content only (relative paths, no data-routing) for the Artifact publisher
dist/play-medal-poker-vN.zip  the hand-off (dist/site + server + tools + README)
"""
import os, re, shutil, zipfile

VERSION = 'v5'
ROOT = os.path.dirname(os.path.abspath(__file__))
html = open(os.path.join(ROOT, 'index.html'), encoding='utf-8').read()
css = open(os.path.join(ROOT, 'styles.css'), encoding='utf-8').read()
js = open(os.path.join(ROOT, 'app.js'), encoding='utf-8').read()

head = re.search(r'<!--BUILD:HEAD-START-->(.*?)<!--BUILD:HEAD-END-->', html, re.S).group(1).strip()
body = re.search(r'<!--BUILD:BODY-START-->(.*?)<!--BUILD:BODY-END-->', html, re.S).group(1).strip()


def absolutize(text):
    """Relative 'assets/…' references → root-absolute '/assets/…' (markup, CSS url(), JS template strings)."""
    return (text.replace('href="styles.css"', 'href="/styles.css"').replace('src="app.js"', 'src="/app.js"')
                .replace('src="assets/', 'src="/assets/')
                .replace('href="assets/', 'href="/assets/')
                .replace('url("assets/', 'url("/assets/')
                .replace("url('assets/", "url('/assets/")
                .replace('src=\\"assets/', 'src=\\"/assets/'))


dist = os.path.join(ROOT, 'dist')
site = os.path.join(dist, 'site')
os.makedirs(dist, exist_ok=True)
shutil.rmtree(site, ignore_errors=True)
os.makedirs(site)

# 1. deploy folder
open(os.path.join(site, 'index.html'), 'w', encoding='utf-8').write(absolutize(html))
open(os.path.join(site, 'styles.css'), 'w', encoding='utf-8').write(absolutize(css))
open(os.path.join(site, 'app.js'), 'w', encoding='utf-8').write(absolutize(js))
shutil.copytree(os.path.join(ROOT, 'assets'), os.path.join(site, 'assets'))
for name in ['robots.txt', '_headers', '_redirects']:
    shutil.copy(os.path.join(ROOT, name), site)

# 2. single-file local preview (relative paths, hash routing)
preview = html.replace('<link rel="stylesheet" href="styles.css">', f'<style>\n{css}\n</style>').replace('<script src="app.js"></script>', f'<script>\n{js}\n</script>')
open(os.path.join(dist, 'preview.html'), 'w', encoding='utf-8').write(preview)
_da = os.path.join(dist, 'assets')
if os.path.islink(_da): os.unlink(_da)
shutil.rmtree(_da, ignore_errors=True)
shutil.copytree(os.path.join(ROOT, 'assets'), _da)

# 3. artifact page (publisher wraps it; relative paths; hash routing)
page = f"""{head}
<style>
{css}
</style>
{body.replace(' data-routing="path"', '')}
<script>
{js}
</script>
"""
open(os.path.join(dist, 'artifact.html'), 'w', encoding='utf-8').write(page)

# 4. hand-off zip
out = os.path.join(dist, f'play-medal-poker-{VERSION}.zip')
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
    for base, _, files in os.walk(site):
        for fn in files:
            p = os.path.join(base, fn)
            z.write(p, 'play-medal-poker/site/' + os.path.relpath(p, site))
    for fn in sorted(os.listdir(os.path.join(ROOT, 'server'))):
        z.write(os.path.join(ROOT, 'server', fn), f'play-medal-poker/server/{fn}')
    z.write(os.path.join(ROOT, 'README.md'), 'play-medal-poker/README.md')
    z.write(os.path.join(ROOT, 'build_icons.py'), 'play-medal-poker/tools/build_icons.py')
    z.write(os.path.join(ROOT, 'build.py'), 'play-medal-poker/tools/build.py')
    for fn in sorted(os.listdir(os.path.join(ROOT, 'icon-sources'))):
        z.write(os.path.join(ROOT, 'icon-sources', fn), f'play-medal-poker/tools/icon-sources/{fn}')
    for name in ['index.html', 'styles.css', 'app.js']:
        z.write(os.path.join(ROOT, name), f'play-medal-poker/src/{name}')
print('artifact.html', len(page) // 1024, 'KB ·', 'zip', os.path.getsize(out) // 1024, 'KB ·', out)
